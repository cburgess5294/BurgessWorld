# EEPROM24
Library for the I2C 24LCxxx chips

Different chips are defined as child classes of a parent EEPROM24 class.

